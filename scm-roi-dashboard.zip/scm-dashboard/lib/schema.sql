-- ============================================================================
-- lib/schema.sql
-- Supabase (PostgreSQL) テーブル定義
-- 財務シミュレーション・マスターモデル（プロセス1〜7横展開版）に対応
-- ============================================================================

create extension if not exists "pgcrypto";

-- 7つの効果プール（二重計上防止フレーム）
create table if not exists effect_pools (
  id            text primary key,          -- 'pool-01' .. 'pool-07'
  name          text not null,
  overlap_note  text
);

-- プロセス1〜7 マスターレコード
create table if not exists process_metrics (
  id                        text primary key,      -- 'p1'..'p7'
  "order"                   smallint not null,
  key                       text not null,          -- 施策コード 'P1-01' など
  process_name              text not null,
  stage_label               text,
  initiative                text not null,
  pool                      text references effect_pools(id),
  capex_oku                 numeric not null,
  opex_oku_per_year         numeric not null,
  opex_nature               text check (opex_nature in ('system','hardware')),
  net_impact_oku_per_year   numeric not null,
  ebit_roi_percent          numeric not null,
  static_payback_years      numeric,
  effective_payback_years   numeric,
  time_to_value_months      smallint,
  evidence_note             text,
  kpi_note                  text,
  owner_functions           text[],
  status                    text check (status in ('on-track','watch','alert')),
  updated_at                timestamptz default now()
);

-- 自社実績 vs 業界平均 ベンチマークデータ
create table if not exists benchmark_data (
  id              uuid primary key default gen_random_uuid(),
  process_id      text references process_metrics(id) on delete cascade,
  label           text not null,
  unit            text,
  company_value   numeric,
  industry_avg    numeric,
  target          numeric,
  direction       text check (direction in ('higher-is-better','lower-is-better'))
);

-- ユーザー（自社）実績KPIの時系列（マルチテナント想定）
create table if not exists user_kpi (
  id              uuid primary key default gen_random_uuid(),
  org_id          uuid not null,
  process_id      text references process_metrics(id) on delete cascade,
  metric_label    text not null,
  actual_value    numeric,
  recorded_at     timestamptz default now()
);

-- ボトム層：4大トレンド（AI需要予測／自動化／トレーサビリティ／Scope3等）
create table if not exists trend_metrics (
  id                    text primary key,
  title                 text not null,
  summary               text,
  related_process_ids   text[],
  data_points           jsonb,              -- [{ "label": "...", "value": 0, "unit": "..." }]
  updated_at            timestamptz default now()
);

-- Row Level Security（マルチテナント運用時に有効化）
alter table user_kpi enable row level security;
create policy "org members can read own kpi"
  on user_kpi for select
  using (org_id = auth.uid());
