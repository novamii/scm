"use client";

import type { PortfolioSummary } from "@/lib/types";

interface KpiBarProps {
  summary: PortfolioSummary | null;
  loading: boolean;
}

function StatTile({
  label,
  value,
  unit,
  accent,
}: {
  label: string;
  value: string;
  unit: string;
  accent?: "teal" | "alert" | "default";
}) {
  const valueColor =
    accent === "teal"
      ? "text-brand-teal"
      : accent === "alert"
      ? "text-brand-alert"
      : "text-ink-900";

  return (
    <div className="flex min-w-[9.5rem] flex-1 flex-col gap-1 border-l border-ink-900/10 px-4 py-3 first:border-l-0 first:pl-0">
      <span className="text-[13px] leading-none text-ink-500">{label}</span>
      <span className={`text-2xl font-semibold leading-tight ${valueColor}`}>
        {value}
        <span className="ml-1 text-sm font-medium text-ink-500">{unit}</span>
      </span>
    </div>
  );
}

function SkeletonTile() {
  return (
    <div className="flex min-w-[9.5rem] flex-1 flex-col gap-2 border-l border-ink-900/10 px-4 py-3 first:border-l-0 first:pl-0">
      <div className="h-3 w-16 animate-pulse rounded bg-ink-900/10" />
      <div className="h-6 w-20 animate-pulse rounded bg-ink-900/10" />
    </div>
  );
}

export default function KpiBar({ summary, loading }: KpiBarProps) {
  return (
    <div className="rounded-card border border-ink-900/10 bg-white/90 px-2 shadow-panel">
      <div className="flex flex-wrap divide-y divide-ink-900/10 sm:divide-y-0">
        {loading || !summary ? (
          <>
            <SkeletonTile />
            <SkeletonTile />
            <SkeletonTile />
            <SkeletonTile />
            <SkeletonTile />
          </>
        ) : (
          <>
            <StatTile label="総CAPEX" value={summary.totalCapexOku.toFixed(1)} unit="億円" />
            <StatTile
              label="年間OPEX"
              value={summary.totalOpexOkuPerYear.toFixed(2)}
              unit="億円/年"
            />
            <StatTile
              label="年間Net Impact"
              value={summary.totalNetImpactOkuPerYear.toFixed(1)}
              unit="億円/年"
              accent="teal"
            />
            <StatTile
              label="加重平均EBIT ROI"
              value={summary.weightedEbitRoiPercent.toFixed(0)}
              unit="%"
              accent="teal"
            />
            <StatTile
              label="実効投資回収"
              value={`${summary.blendedPaybackYearsRange[0]}〜${summary.blendedPaybackYearsRange[1]}`}
              unit="年"
            />
          </>
        )}
      </div>
    </div>
  );
}
