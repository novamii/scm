"use client";

import type { ProcessMetric } from "@/lib/types";
import ProcessCard from "./ProcessCard";

interface ProcessGridProps {
  processes: ProcessMetric[];
  loading: boolean;
  onOpen: (id: string) => void;
}

function CardSkeleton() {
  return (
    <div className="flex h-full flex-col gap-3 rounded-card border border-ink-900/10 bg-white p-4 shadow-panel">
      <div className="h-3 w-20 animate-pulse rounded bg-ink-900/10" />
      <div className="h-4 w-32 animate-pulse rounded bg-ink-900/10" />
      <div className="h-3 w-full animate-pulse rounded bg-ink-900/10" />
      <div className="mt-4 grid grid-cols-2 gap-3">
        <div className="h-8 animate-pulse rounded bg-ink-900/10" />
        <div className="h-8 animate-pulse rounded bg-ink-900/10" />
      </div>
    </div>
  );
}

export default function ProcessGrid({ processes, loading, onOpen }: ProcessGridProps) {
  return (
    <div>
      <h2 className="mb-3 text-base font-semibold text-ink-900">
        プロセス別 ROI サマリー（7プロセス）
      </h2>
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
        {loading
          ? Array.from({ length: 7 }).map((_, i) => <CardSkeleton key={i} />)
          : processes.map((p) => (
              <ProcessCard key={p.id} process={p} onOpen={onOpen} />
            ))}
      </div>
    </div>
  );
}
