"use client";

import type { ProcessMetric } from "@/lib/types";

interface ProcessCardProps {
  process: ProcessMetric;
  onOpen: (id: string) => void;
}

const statusMeta: Record<
  ProcessMetric["status"],
  { label: string; textClass: string; dotClass: string }
> = {
  "on-track": { label: "計画通り", textClass: "text-brand-teal", dotClass: "bg-brand-teal" },
  watch: { label: "要観察", textClass: "text-ink-500", dotClass: "bg-brand-grey" },
  alert: { label: "ROI未達", textClass: "text-brand-alert", dotClass: "bg-brand-alert" },
};

export default function ProcessCard({ process, onOpen }: ProcessCardProps) {
  const { financial } = process;
  const roiIsNegative = financial.ebitRoiPercent < 0;
  const meta = statusMeta[process.status];

  return (
    <button
      onClick={() => onOpen(process.id)}
      className="group flex h-full flex-col rounded-card border border-ink-900/10 bg-white p-4 text-left shadow-panel transition-transform hover:-translate-y-0.5 hover:border-brand-green/60 focus-visible:-translate-y-0.5"
    >
      <div className="mb-2 flex items-center justify-between">
        <span className="text-[11px] font-medium uppercase tracking-wide text-ink-500">
          {process.stageLabel} ／ {process.key}
        </span>
        <span className={`flex items-center gap-1 text-[11px] font-medium ${meta.textClass}`}>
          <span className={`h-1.5 w-1.5 rounded-full ${meta.dotClass}`} />
          {meta.label}
        </span>
      </div>

      <h3 className="text-[15px] font-semibold leading-snug text-ink-900">
        {process.processName}
      </h3>
      <p className="mt-1 line-clamp-2 text-xs leading-relaxed text-ink-500">
        {process.initiative}
      </p>

      <div className="mt-4 grid grid-cols-2 gap-x-3 gap-y-2.5 border-t border-ink-900/10 pt-3">
        <div>
          <p className="text-[11px] text-ink-500">Net Impact/年</p>
          <p className="text-base font-semibold text-brand-teal">
            +{financial.netImpactOkuPerYear.toFixed(2)}億円
          </p>
        </div>
        <div>
          <p className="text-[11px] text-ink-500">EBIT ROI</p>
          <p
            className={`text-base font-semibold ${
              roiIsNegative ? "text-brand-alert" : "text-ink-900"
            }`}
          >
            {financial.ebitRoiPercent > 0 ? "+" : ""}
            {financial.ebitRoiPercent.toFixed(1)}%
          </p>
        </div>
        <div>
          <p className="text-[11px] text-ink-500">CAPEX</p>
          <p className="text-sm font-medium text-ink-900">{financial.capexOku.toFixed(1)}億円</p>
        </div>
        <div>
          <p className="text-[11px] text-ink-500">実効回収期間</p>
          <p className="text-sm font-medium text-ink-900">
            {Number.isNaN(financial.effectivePaybackYears)
              ? "複数年評価要"
              : `約${financial.effectivePaybackYears.toFixed(2)}年`}
          </p>
        </div>
      </div>

      <span className="mt-3 self-start text-xs font-medium text-brand-teal underline-offset-2 group-hover:underline">
        ベンチマークを見る →
      </span>
    </button>
  );
}
