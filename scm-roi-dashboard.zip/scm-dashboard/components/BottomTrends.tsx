"use client";

import { ResponsiveContainer, BarChart, Bar, XAxis, Tooltip } from "recharts";
import type { TrendMetric } from "@/lib/types";

interface BottomTrendsProps {
  trends: TrendMetric[];
  loading: boolean;
}

function TrendSkeleton() {
  return (
    <div className="flex h-full flex-col gap-3 rounded-card border border-ink-900/10 bg-white p-4 shadow-panel">
      <div className="h-3 w-24 animate-pulse rounded bg-ink-900/10" />
      <div className="h-4 w-full animate-pulse rounded bg-ink-900/10" />
      <div className="h-4 w-2/3 animate-pulse rounded bg-ink-900/10" />
      <div className="mt-auto h-16 w-full animate-pulse rounded bg-ink-900/10" />
    </div>
  );
}

export default function BottomTrends({ trends, loading }: BottomTrendsProps) {
  return (
    <div>
      <h2 className="mb-3 text-base font-semibold text-ink-900">
        4大トレンド管理（AI需要予測・自動化・トレーサビリティ・Scope3）
      </h2>
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-4">
        {loading
          ? Array.from({ length: 4 }).map((_, i) => <TrendSkeleton key={i} />)
          : trends.map((t) => (
              <div
                key={t.id}
                className="flex h-full flex-col rounded-card border border-ink-900/10 bg-white p-4 shadow-panel"
              >
                <span className="text-[11px] font-medium text-brand-teal">
                  関連プロセス {t.relatedProcessIds.length}件
                </span>
                <h3 className="mt-1 text-sm font-semibold leading-snug text-ink-900">
                  {t.title}
                </h3>
                <p className="mt-1.5 line-clamp-3 text-xs leading-relaxed text-ink-500">
                  {t.summary}
                </p>

                <div className="mt-3 h-16 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={t.dataPoints} margin={{ top: 4 }}>
                      <XAxis
                        dataKey="label"
                        tick={{ fontSize: 9, fill: "#6B7370" }}
                        tickLine={false}
                        axisLine={{ stroke: "#1C232120" }}
                        interval={0}
                      />
                      <Tooltip
                        contentStyle={{ fontSize: 11, borderRadius: 8 }}
                        formatter={(value: any, _key: any, item: any) => [
                          `${value}${item?.payload?.unit ?? ""}`,
                          "実績",
                        ]}
                      />
                      <Bar dataKey="value" fill="#94CE47" radius={[3, 3, 0, 0]} barSize={28} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>

                <p className="mt-2 text-[10px] text-ink-500">更新日：{t.updatedAt}</p>
              </div>
            ))}
      </div>
    </div>
  );
}
