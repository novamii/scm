"use client";

import type { ProcessMetric } from "@/lib/types";

interface FlowDiagramProps {
  processes: ProcessMetric[];
  activeId: string | null;
  onSelect: (id: string) => void;
}

const statusDot: Record<ProcessMetric["status"], string> = {
  "on-track": "bg-brand-teal",
  watch: "bg-brand-grey",
  alert: "bg-brand-alert",
};

export default function FlowDiagram({ processes, activeId, onSelect }: FlowDiagramProps) {
  return (
    <div className="relative rounded-card border border-ink-900/10 bg-white p-4 shadow-panel sm:p-6">
      <div className="mb-4 flex items-baseline justify-between">
        <h2 className="text-base font-semibold text-ink-900">
          調達 → 循環：サプライチェーン全体フロー
        </h2>
        <span className="text-xs text-ink-500">タップでベンチマーク詳細を表示</span>
      </div>

      <div className="scrollbar-hide flex items-stretch gap-0 overflow-x-auto pb-3">
        {processes.map((p, idx) => {
          const isActive = p.id === activeId;
          return (
            <div key={p.id} className="flex items-center">
              <button
                onClick={() => onSelect(p.id)}
                aria-pressed={isActive}
                className={`group flex w-[7.5rem] shrink-0 flex-col items-start gap-1.5 rounded-card border px-3 py-3 text-left transition-colors sm:w-36 ${
                  isActive
                    ? "border-brand-green bg-brand-green/10"
                    : "border-ink-900/10 bg-white hover:border-brand-green/60"
                }`}
              >
                <span className="text-[11px] font-medium text-ink-500">{p.key}</span>
                <span className="text-sm font-semibold leading-snug text-ink-900">
                  {p.processName}
                </span>
                <span className="flex items-center gap-1.5 text-[11px] text-ink-500">
                  <span className={`h-1.5 w-1.5 rounded-full ${statusDot[p.status]}`} />
                  ROI {p.financial.ebitRoiPercent.toFixed(0)}%
                </span>
              </button>
              {idx < processes.length - 1 && (
                <svg
                  width="28"
                  height="16"
                  viewBox="0 0 28 16"
                  className="shrink-0 text-ink-900/25"
                  aria-hidden="true"
                >
                  <line x1="0" y1="8" x2="20" y2="8" stroke="currentColor" strokeWidth="1.5" />
                  <path d="M20 3 L27 8 L20 13" fill="none" stroke="currentColor" strokeWidth="1.5" />
                </svg>
              )}
            </div>
          );
        })}
      </div>

      {/* リサイクル・フィードバックループ（点線矢印）：P7 -> P1 */}
      <div className="mt-1 flex items-center gap-2 border-t border-dashed border-brand-teal/40 pt-3">
        <svg width="20" height="20" viewBox="0 0 20 20" className="shrink-0 text-brand-teal" aria-hidden="true">
          <path
            d="M4 10a6 6 0 0 1 10.2-4.3M16 10a6 6 0 0 1-10.2 4.3"
            fill="none"
            stroke="currentColor"
            strokeWidth="1.6"
            strokeDasharray="2.5 2.5"
          />
          <path d="M14.6 4.5 L14.2 6.7 L12 6.1" fill="none" stroke="currentColor" strokeWidth="1.6" />
          <path d="M5.4 15.5 L5.8 13.3 L8 13.9" fill="none" stroke="currentColor" strokeWidth="1.6" />
        </svg>
        <p className="text-xs leading-relaxed text-ink-500">
          プロセス7（消費・リサイクル・循環）で得られる代替原料・再生資源データは、プロセス1（調達・購買）の調達計画へフィードバックされる（点線＝循環ループ）。
        </p>
      </div>
    </div>
  );
}
