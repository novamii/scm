"use client";

import { useEffect, useRef } from "react";
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Legend,
} from "recharts";
import type { ProcessMetric } from "@/lib/types";

interface ProcessModalProps {
  process: ProcessMetric | null;
  onClose: () => void;
}

export default function ProcessModal({ process, onClose }: ProcessModalProps) {
  const closeButtonRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    if (process) closeButtonRef.current?.focus();
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [process, onClose]);

  if (!process) return null;

  const chartData = process.benchmarks.map((b) => ({
    name: b.label.length > 12 ? `${b.label.slice(0, 12)}…` : b.label,
    fullName: b.label,
    自社実績: b.companyValue,
    業界平均: b.industryAvg,
    目標値: b.target,
    unit: b.unit,
  }));

  return (
    <div
      className="fixed inset-0 z-50 flex items-end justify-center bg-ink-900/40 sm:items-center sm:p-4"
      role="dialog"
      aria-modal="true"
      aria-label={`${process.processName} ベンチマーク詳細`}
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="max-h-[88vh] w-full overflow-y-auto rounded-t-card border border-ink-900/10 bg-white shadow-panel sm:max-h-[85vh] sm:max-w-lg sm:rounded-card"
      >
        <div className="sticky top-0 z-10 flex items-start justify-between gap-3 border-b border-ink-900/10 bg-white px-5 py-4">
          <div>
            <span className="text-[11px] font-medium uppercase tracking-wide text-ink-500">
              {process.stageLabel} ／ {process.key}
            </span>
            <h3 className="text-lg font-semibold leading-snug text-ink-900">
              {process.processName}
            </h3>
          </div>
          <button
            ref={closeButtonRef}
            onClick={onClose}
            aria-label="閉じる"
            className="rounded-full border border-ink-900/10 p-1.5 text-ink-500 hover:bg-ink-900/5"
          >
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true">
              <path d="M2 2L14 14M14 2L2 14" stroke="currentColor" strokeWidth="1.6" />
            </svg>
          </button>
        </div>

        <div className="space-y-5 px-5 py-4">
          <p className="text-sm leading-relaxed text-ink-700">{process.initiative}</p>

          <div className="grid grid-cols-3 gap-2">
            <MetricPill label="CAPEX" value={`${process.financial.capexOku.toFixed(1)}億円`} />
            <MetricPill
              label="年間OPEX"
              value={`${process.financial.opexOkuPerYear.toFixed(2)}億円`}
              hint={process.financial.opexNature === "system" ? "システム系15%" : "ハードウェア系5%"}
            />
            <MetricPill
              label="Net Impact/年"
              value={`+${process.financial.netImpactOkuPerYear.toFixed(2)}億円`}
              accent
            />
          </div>

          <div>
            <h4 className="mb-2 text-sm font-semibold text-ink-900">
              自社実績 vs 業界平均 vs 目標値
            </h4>
            <div className="h-56 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData} margin={{ left: -18, right: 8, top: 4 }}>
                  <CartesianGrid stroke="#1C232112" vertical={false} />
                  <XAxis
                    dataKey="name"
                    tick={{ fontSize: 11, fill: "#6B7370" }}
                    tickLine={false}
                    axisLine={{ stroke: "#1C232120" }}
                  />
                  <YAxis tick={{ fontSize: 11, fill: "#6B7370" }} tickLine={false} axisLine={false} />
                  <Tooltip
                    contentStyle={{ fontSize: 12, borderRadius: 8, borderColor: "#1C232120" }}
                    formatter={(value: any, key: any, item: any) => [
                      `${value}${item?.payload?.unit ?? ""}`,
                      key,
                    ]}
                  />
                  <Legend wrapperStyle={{ fontSize: 11 }} />
                  <Bar dataKey="業界平均" fill="#9AA1AC" radius={[3, 3, 0, 0]} />
                  <Bar dataKey="自社実績" fill="#94CE47" radius={[3, 3, 0, 0]} />
                  <Bar dataKey="目標値" fill="#2B7A78" radius={[3, 3, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="space-y-3 rounded-card bg-ink-900/[0.03] p-3.5">
            <div>
              <p className="text-[11px] font-medium text-ink-500">Layer1：エビデンス</p>
              <p className="text-xs leading-relaxed text-ink-700">{process.evidenceNote}</p>
            </div>
            <div>
              <p className="text-[11px] font-medium text-ink-500">Layer2：運用KPI</p>
              <p className="text-xs leading-relaxed text-ink-700">{process.kpiNote}</p>
            </div>
            <div>
              <p className="text-[11px] font-medium text-ink-500">主管部門</p>
              <p className="text-xs leading-relaxed text-ink-700">
                {process.ownerFunctions.join(" ／ ")}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function MetricPill({
  label,
  value,
  hint,
  accent,
}: {
  label: string;
  value: string;
  hint?: string;
  accent?: boolean;
}) {
  return (
    <div className="rounded-card border border-ink-900/10 px-2.5 py-2">
      <p className="text-[10px] text-ink-500">{label}</p>
      <p className={`text-sm font-semibold ${accent ? "text-brand-teal" : "text-ink-900"}`}>
        {value}
      </p>
      {hint && <p className="text-[10px] text-ink-500">{hint}</p>}
    </div>
  );
}
