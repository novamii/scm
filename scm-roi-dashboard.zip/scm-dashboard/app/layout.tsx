import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "サプライチェーンROIダッシュボード｜プロセス1〜7 財務シミュレーション",
  description:
    "調達から製造・流通・循環までの7プロセスを横断し、ROI・KPI・ベンチマークを可視化するダッシュボード。",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="ja">
      <body className="font-body antialiased">{children}</body>
    </html>
  );
}
