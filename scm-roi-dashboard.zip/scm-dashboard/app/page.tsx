"use client";

import { useEffect, useState } from "react";
import type { ProcessMetric, TrendMetric, PortfolioSummary } from "@/lib/types";
import {
  fetchProcessMetrics,
  fetchTrendMetrics,
  fetchPortfolioSummary,
} from "@/lib/supabaseClient";
import KpiBar from "@/components/KpiBar";
import FlowDiagram from "@/components/FlowDiagram";
import ProcessGrid from "@/components/ProcessGrid";
import ProcessModal from "@/components/ProcessModal";
import BottomTrends from "@/components/BottomTrends";

export default function DashboardPage() {
  const [processes, setProcesses] = useState<ProcessMetric[]>([]);
  const [trends, setTrends] = useState<TrendMetric[]>([]);
  const [summary, setSummary] = useState<PortfolioSummary | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [activeId, setActiveId] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;

    async function load() {
      setLoading(true);
      setError(null);
      try {
        const [p, t, s] = await Promise.all([
          fetchProcessMetrics(),
          fetchTrendMetrics(),
          fetchPortfolioSummary(),
        ]);
        if (cancelled) return;
        setProcesses(p);
        setTrends(t);
        setSummary(s);
      } catch (e) {
        if (!cancelled) setError("データの取得に失敗しました。時間をおいて再度お試しください。");
      } finally {
        if (!cancelled) setLoading(false);
      }
    }

    load();
    return () => {
      cancelled = true;
    };
  }, []);

  const activeProcess = processes.find((p) => p.id === activeId) ?? null;

  return (
    <main className="mx-auto max-w-6xl px-4 py-6 sm:px-6 sm:py-10">
      <header className="mb-6">
        <p className="text-xs font-medium text-brand-teal">
          食品メーカー サプライチェーンROIダッシュボード
        </p>
        <h1 className="mt-1 text-2xl font-bold leading-tight text-ink-900 sm:text-3xl">
          調達〜製造〜流通〜循環　7プロセス財務シミュレーション
        </h1>
        <p className="mt-2 max-w-2xl text-sm leading-relaxed text-ink-500">
          6層構造エビデンスチェーン × 7つの効果プール（二重計上防止）に基づく投資判断ダッシュボード。
          各プロセスカードから、自社実績と業界平均のベンチマーク比較を確認できます。
        </p>
      </header>

      {error && (
        <div className="mb-4 rounded-card border border-brand-alert/30 bg-brand-alert/5 px-4 py-3 text-sm text-brand-alert">
          {error}
        </div>
      )}

      {/* ── トップ層：全体フロー＋ROIサマリー ─────────────────────── */}
      <section className="mb-6 space-y-4">
        <KpiBar summary={summary} loading={loading} />
        {!loading && processes.length > 0 && (
          <FlowDiagram processes={processes} activeId={activeId} onSelect={setActiveId} />
        )}
      </section>

      {/* ── ミドル層：7プロセス詳細パネル ─────────────────────────── */}
      <section className="mb-8">
        <ProcessGrid processes={processes} loading={loading} onOpen={setActiveId} />
      </section>

      {/* ── ボトム層：4カラム主要トレンド管理 ─────────────────────── */}
      <section>
        <BottomTrends trends={trends} loading={loading} />
      </section>

      <ProcessModal process={activeProcess} onClose={() => setActiveId(null)} />

      <footer className="mt-10 border-t border-ink-900/10 pt-4 text-[11px] leading-relaxed text-ink-500">
        本ダッシュボードの数値はベストプラクティス定義書に基づく財務シミュレーション（一部
        ASSUMPTION 前提を含む）です。実運用時は Supabase 上の実績データに置き換えてください。
      </footer>
    </main>
  );
}
